from backends.base import *


def BackendMPI(*args,**kwargs):
    from backends.mpi import BackendMPI
    return BackendMPI(*args,**kwargs)

def BackendMPITestHelper(*args,**kwargs):
    from backends.mpi import BackendMPITestHelper
    return BackendMPITestHelper(*args,**kwargs)

def BackendSpark(*args,**kwargs):
    from  backends.spark import BackendSpark
    return BackendSpark(*args,**kwargs)
